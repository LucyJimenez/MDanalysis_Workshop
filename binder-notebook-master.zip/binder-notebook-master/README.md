This is a collection of interactive jupyter notebooks to showcase
[MDAnalysis](https://www.mdanalysis.org). To start a notebook server in the
cloud you can click on the *launch binder* button below.


[![Binder](https://mybinder.org/badge.svg)](https://mybinder.org/v2/gh/MDAnalysis/binder-notebook/master?filepath=notebooks)


Alternatively you can also download this repository and run the notebooks
locally.
